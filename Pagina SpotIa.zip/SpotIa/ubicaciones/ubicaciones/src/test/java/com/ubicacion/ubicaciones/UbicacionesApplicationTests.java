package com.ubicacion.ubicaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UbicacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
